package com.deepanshuPanwar.learnspringaop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnSpringAopApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnSpringAopApplication.class, args);
	}

}
