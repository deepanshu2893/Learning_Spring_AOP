package com.DeepanshuPanwar.learningspringaop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningSpringAopApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningSpringAopApplication.class, args);
	}

}
