package com.DeepanshuPanwar.learningspringaop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningSpringAopApplicationTests {

	@Test
	void contextLoads() {
	}

}
